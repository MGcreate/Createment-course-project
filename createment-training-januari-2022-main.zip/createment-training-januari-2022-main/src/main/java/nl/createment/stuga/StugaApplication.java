package nl.createment.stuga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StugaApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(StugaApplication.class, args);
	}
}