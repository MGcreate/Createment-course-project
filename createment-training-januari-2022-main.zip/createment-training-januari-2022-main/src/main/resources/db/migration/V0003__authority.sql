ALTER TABLE public.messenger
ADD authorities character varying(255) DEFAULT 'USER';
