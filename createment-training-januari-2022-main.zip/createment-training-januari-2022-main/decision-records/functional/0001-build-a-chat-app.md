# 0001. Build a chat app
Date: 2022-01-14

## Status
Approved

## Context
We are doing a case assignment for Createment and we are building a real application to gain experience in software development. We need to decide what exactly to build.

## Decision
We will build a chat application.

## Consequences
There are a lot of different things we could be building. Picking a known kind of application will make sure it's easy to align between the participants, both students and trainers.
