# 0001. Pick Spring Boot
Date: 2022-01-14

## Status
Accepted

## Context
We are doing a case assignment for Createment and we are building a real application to gain experience in software development. We need to decide how to build it. We have recently been trained in the usage of tools like Spring Boot and JPA. The goal of the case is to gain experience using the tools we've been trained to use.

## Decision
We will build our application using Spring Boot and JPA.

## Consequences
There are lots of frameworks out there, some better than others. By picking one, we won't get the opportunity to learn any of the others. But we need to pick _something_, and this is what we know.
